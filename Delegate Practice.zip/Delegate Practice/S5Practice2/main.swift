import Foundation

var o:OrderInfo=OrderInfo()
var c:LowCreditCustomer=LowCreditCustomer()
var cs:Customer=Customer()
o.delegate = c
cs.credit = 100999
o.customer = cs
o.buy(amount: 100001)





