
import Foundation

class OrderInfo {
    var orderID:Int = 0
    var orderDate:Int = 0
    
    var customer:Customer=Customer()
    
    var delegate:OrderInfoDelegate?
    
    
    func buy(amount:Int) {
        
        
        if customer.credit>=amount {
            print("Buy Done!")
            
            
        } else {
            delegate?.lowCredit(money: amount-customer.credit)
        }
        
    }
    
    
}
