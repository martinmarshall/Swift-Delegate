

import Foundation

class LowCreditCustomer:OrderInfoDelegate {
    
    func lowCredit(money:Int) {
        print("Low Credit   Money Needed: \(money)$")
    }
}
