
import Foundation



class Customer {
    var credit:Int = 0
    var customerName:String = ""

}


