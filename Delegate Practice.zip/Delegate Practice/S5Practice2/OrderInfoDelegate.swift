
import Foundation

protocol OrderInfoDelegate {
    func lowCredit(money:Int)
}

